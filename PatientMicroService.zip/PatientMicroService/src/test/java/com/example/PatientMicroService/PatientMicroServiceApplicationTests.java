package com.example.PatientMicroService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
