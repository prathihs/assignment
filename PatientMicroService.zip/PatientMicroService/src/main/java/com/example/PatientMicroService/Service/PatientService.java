package com.example.PatientMicroService.Service;

import com.example.PatientMicroService.Model.Patient;

import java.util.List;

public interface PatientService {
    Patient registerPatient(Patient patient);
    List<Patient> getAllPatients();
    Patient getPatientById(int id);
    Patient getPatientByName(String name);
    Patient getPatientByDoc(String Docname);
    List<Patient> getPatientsByStage(String stage);
    Patient updatePatientById(int id,Patient patient);
    boolean delete(int id);
}
