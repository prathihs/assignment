package com.example.PatientMicroService.Controller;

import com.example.PatientMicroService.Model.Patient;
import com.example.PatientMicroService.Service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/patients")
public class PatientController {

    @Autowired
    private PatientService patientService;

    @PostMapping("/register")
    public Patient registerPatient(@RequestBody Patient patient) {
        return patientService.registerPatient(patient);
    }

    @GetMapping("/all")
    public List<Patient> getAllPatients() {
        return patientService.getAllPatients();
    }

    @GetMapping("/{id}")
    public Patient getPatientById(@PathVariable int id) {
        return patientService.getPatientById(id);
    }

    @GetMapping("/name/{name}")
    public Patient getPatientByName(@PathVariable String name) {
        return patientService.getPatientByName(name);
    }

    @GetMapping("/doc/{docName}")
    public Patient getPatientByDoc(@PathVariable String docName) {
        return patientService.getPatientByDoc(docName);
    }

    @GetMapping("/stage/{stage}")
    public List<Patient> getPatientsByStage(@PathVariable String stage) {
        return patientService.getPatientsByStage(stage);
    }

    @PutMapping("/update/{id}")
    public Patient updateByPatientId(@PathVariable int id, @RequestBody Patient updatedPatient) {
        return patientService.updatePatientById(id, updatedPatient);
    }

    @DeleteMapping("/delete/{id}")
    public boolean deletePatient(@PathVariable int id) {
        return patientService.delete(id);
    }
}