package com.example.PatientMicroService.Service;

import com.example.PatientMicroService.Model.Patient;
import com.example.PatientMicroService.Repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PatientServiceImpl implements PatientService {
    @Autowired
    private PatientRepository patientRepository;

    @Override
    public Patient registerPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    @Override
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    @Override
    public Patient getPatientById(int id) {
        Optional<Patient> optionalPatient = patientRepository.findById(id);
        return optionalPatient.orElse(null);
    }

    @Override
    public Patient getPatientByName(String name) {
        return patientRepository.findByName(name);
    }

    @Override
    public Patient getPatientByDoc(String docName) {
        return patientRepository.findByDoc(docName);
    }

    @Override
    public List<Patient> getPatientsByStage(String stage) {
        return patientRepository.findByStage(stage);
    }

    @Override
    public Patient updatePatientById(int id, Patient updatedPatient) {
        Optional<Patient> optionalPatient = patientRepository.findById(id);
        if (optionalPatient.isPresent()) {
            Patient existingPatient = optionalPatient.get();
            existingPatient.setName(updatedPatient.getName());
            existingPatient.setDisease(updatedPatient.getDisease());
            existingPatient.setDoc(updatedPatient.getDoc());
            existingPatient.setStage(updatedPatient.getStage());
            return patientRepository.save(existingPatient);
        }
        return null;
    }

    @Override
    public boolean delete(int id) {
        Optional<Patient> optionalPatient = patientRepository.findById(id);
        if (optionalPatient.isPresent()) {
            patientRepository.deleteById(id);
            return true;
        }
        return false;
    }
}

